import studentiIO
# studentiIO.putanja = 'studenti1.csv'

def pronalazenje_studenta_po_broju_indeksa(broj_indeksa):
    studenti = studentiIO.ucitaj()
    for student in studenti:
        if broj_indeksa == student['broj_indeksa']:
            return student
    return None

def pronalazenje_studenata_po_prezimenu(prezime):
    studenti = studentiIO.ucitaj()
    studenti_za_prikaz = []
    for student in studenti:
        if prezime.lower() in student['prezime'].lower():
            studenti_za_prikaz.append(student)
    return studenti_za_prikaz

def ucitaj_sve_student():
    studenti = studentiIO.ucitaj()
    studenti.sort(key = lambda x:x['prezime'])
    return studenti

def dodaj_studenta(ime, prezime, broj_indeksa, jmbg, email, telefon):
    novi_student = {'ime' : ime, 'prezime' : prezime, 'broj_indeksa' : broj_indeksa, 'JMBG' : jmbg, 'email':email, 'telefon':telefon, 'godina':'1'}
    studenti = studentiIO.ucitaj()
    studenti.append(novi_student)
    studentiIO.snimi(studenti)

def izmeni_studenta(broj_indeksa, email, telefon):
    studenti = studentiIO.ucitaj()
    for student in studenti:
        if student['broj_indeksa'] == broj_indeksa:
            student['email'] = email
            student['telefon'] = telefon
    studentiIO.snimi(studenti)

def grupni_upis(indeksi):
    studenti = studentiIO.ucitaj()
    for indeks in indeksi:
        for student in studenti:
            if student['broj_indeksa'] == indeks:
                if int(student['godina'])<5:
                    student['godina'] = str(int(student['godina'])+1)
                    break
    studentiIO.snimi(studenti)            

def brisanje_studenta(broj_indeksa):
    studenti = studentiIO.ucitaj()
    for student in studenti:
        if student['broj_indeksa'] == broj_indeksa:
            student['obrisan'] = True
    studentiIO.snimi(studenti)