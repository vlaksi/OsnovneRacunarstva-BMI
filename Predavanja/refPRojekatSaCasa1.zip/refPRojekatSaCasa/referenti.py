import referentiIO

def autentikacija(korisnicko_ime, lozinka):
    referenti = referentiIO.ucitaj('referenti.csv')
    for referent in referenti:
        if korisnicko_ime == referent['korisnicko_ime'] and lozinka == referent['lozinka']:
            return referent
    return None