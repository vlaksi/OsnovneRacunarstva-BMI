putanja = 'studenti.csv'

def str_to_bool(x):
    if x == 'True':
        return True
    else:
        return False

def red_u_recnik(red):
    red_l = red.split('|')
    student = {'broj_indeksa': red_l[0], 'ime': red_l[1], 'prezime': red_l[2],'JMBG': red_l[3], 'email': red_l[4], 'telefon': red_l[5], 'godina': red_l[6], 'obrisan': str_to_bool(red_l[7])}
    return student

def recnik_u_red(student):
    ret_val = student['broj_indeksa']+'|'+student['ime']+'|'+student['prezime']+'|'+student['JMBG'] + '|' + student['email'] + '|' + student['telefon']+'|'+student['godina'] + '|' + str(student['obrisan'])
    return ret_val

def ucitaj():
    f_in = open(putanja,'r')
    redovi = f_in.readlines()
    studenti = []
    for red in redovi:
        student = red_u_recnik(red.strip())
        if not student['obrisan']:
            studenti.append(student)
    return studenti 

def snimi(studenti):
    f_out = open(putanja,'w')
    for student in studenti:
        print(recnik_u_red(student), file=f_out)
    f_out.close()
