def red_u_recnik(red):
    # Pera|Peric => {'ime':'Pera','prezime':'Peric'}
    red_l = red.split('|')
    referent = {'ime': red_l[0], 'prezime': red_l[1],'korisnicko_ime': red_l[2], 'lozinka': red_l[3], 'rola': red_l[4]}
    return referent

def ucitaj(fajl):
    f_in = open(fajl,'r')
    redovi = f_in.readlines()
    referenti = []
    for red in redovi:
        referenti.append(red_u_recnik(red.strip()))
    return referenti 
