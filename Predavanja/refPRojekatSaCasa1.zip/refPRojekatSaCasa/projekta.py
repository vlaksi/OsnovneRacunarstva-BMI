import referenti
import studenti

def prijava():
    brojac = 0
    while True:
        korisnicko_ime = input('korisnicko ime:')
        lozinka = input('lozinka:')
        brojac += 1
        referent = referenti.autentikacija(korisnicko_ime, lozinka) 
        if referent:
            return referent 
        if brojac >= 3:
            return None

def prikazi_meni_admin():
    print('1) pronalazenje studenta po broju indeksa') # ref,admin
    print('2) pronalazenje studenta po prezimenu') # ref,admin
    print('3) prikaz svih studenata') # ref,admin
    print('4) izmena podataka studenta') # admin
    print('5) dodavanje studenta') # ref,admin
    print('6) grupni upis') # ref,admin
    print('7) brisanje studenta') # admin
    print('x) kraj') # ref,admin

def prikazi_meni_ref():
    print('1) pronalazenje studenta po broju indeksa') # ref,admin
    print('2) pronalazenje studenta po prezimenu') # ref,admin
    print('3) prikaz svih studenata') # ref,admin
    print('4) dodavanje studenta') # ref,admin
    print('5) grupni upis') # ref,admin
    print('x) kraj') # ref,admin

def main():
    ulogovani_referent = prijava()
    if ulogovani_referent:
        while True:
            if ulogovani_referent['rola'] == 'admin':
                kraj = akcije_admin()
                if kraj:
                    break
            elif ulogovani_referent['rola'] == 'ref':
                kraj = akcije_referent()
                if kraj:
                    break
    print('dovidjenja!')

# TODO izmena koda komande sada se radi na dva mesta. Na primer ako bismo dodali novi atribut za korisnika, morali bismo da menjamo i funkciju akcije_admin() i funkciju akcije_referent(). Kako biste resili da se izbegne ovaj problem?
def akcije_admin():
    prikazi_meni_admin()
    komanda = input('komanda:')
    if komanda == '1':
        # pronalazenje studenta po indeksu
        broj_indeksa = input('broj indeksa:')
        student = studenti.pronalazenje_studenta_po_broju_indeksa(broj_indeksa)
        tabela_studenata([student])
    elif komanda == '2':
        # pronalazenje studenata po prezimenu
        prezime = input('prezime:')
        tabela_studenata(studenti.pronalazenje_studenata_po_prezimenu(prezime))
    elif komanda == '3':
        # ispis studenata
        svi_studenti = studenti.ucitaj_sve_student()
        tabela_studenata(svi_studenti)
    elif komanda == '4':
        # izmena studenta
        broj_indeksa = input('broj indeksa:')
        student = studenti.pronalazenje_studenta_po_broju_indeksa(broj_indeksa)
        tabela_studenata([student])
        if student == None:
            print('ne postoji')
        else:
            email = input('email:')
            telefon = input('telefon:')
            studenti.izmeni_studenta(broj_indeksa, email, telefon)
    elif komanda == '5':
        # upis studenta
        ime = input('ime:')
        prezime = input('prezime:')
        broj_indeksa = input('broj indeksa:')
        jmbg = input('jmbg:')
        email = input('email:')
        telefon = input('telefon:')
        studenti.dodaj_studenta(ime, prezime, broj_indeksa, jmbg, email, telefon)
    elif komanda == '6':
        # grupni upis godine
        indeksi_s = input('indeksi (razdvojeni razmakom): ')
        studenti.grupni_upis(indeksi_s.split())
    elif komanda == '7':
        broj_indeksa = input('broj indeksa:')
        studenti.brisanje_studenta(broj_indeksa)
    elif komanda == 'x':
        return True
    else:
        print('komanda nije prepoznata')

def akcije_referent():
    prikazi_meni_ref()
    komanda = input('komanda:')
    if komanda == '1':
        # pronalazenje studenta po indeksu
        broj_indeksa = input('broj indeksa:')
        student = studenti.pronalazenje_studenta_po_broju_indeksa(broj_indeksa)
        tabela_studenata([student])
    elif komanda == '2':
        # pronalazenje studenata po prezimenu
        prezime = input('prezime:')
        tabela_studenata(studenti.pronalazenje_studenata_po_prezimenu(prezime))
    elif komanda == '3':
        # ispis studenata
        svi_studenti = studenti.ucitaj_sve_student()
        tabela_studenata(svi_studenti)
    elif komanda == '4':
        # upis studenta
        ime = input('ime:')
        prezime = input('prezime:')
        broj_indeksa = input('broj indeksa:')
        jmbg = input('jmbg:')
        email = input('email:')
        telefon = input('telefon:')
        studenti.dodaj_studenta(ime, prezime, broj_indeksa, jmbg, email, telefon)
    elif komanda == '5':
        # grupni upis godine
        indeksi_s = input('indeksi (razdvojeni razmakom): ')
        studenti.grupni_upis(indeksi_s.split())
    elif komanda == 'x':
        return True
    else:
        print('komanda nije prepoznata')


def tabela_studenata(studenti):
    print('broj indeksa|ime     |prezime    |JMBG          |email        |telefon     |godina')
    print('--------------------------------------------------------------------------------------')
    for student in studenti:
        if student:
            print(student['broj_indeksa'].rjust(12)+'|'+student['ime'][:8].ljust(8)+'|'+student['prezime'][:11].ljust(11)+'|'+student['JMBG'][:14].ljust(14)+'|'+student['email'][:13].ljust(13)+'|'+student['telefon'][:12].ljust(12)+'|'+student['godina'])


if __name__ == "__main__":
    main()
