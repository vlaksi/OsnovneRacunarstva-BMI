def line_to_student(line):
	l = line.strip().split('|')
	student = {'br_indeksa':l[0],
	'ime':l[1],
	'prezime':l[2],
	'ime_roditelja':l[3],
	'datum_rodjenja':l[4],
	'JMBG':l[5]}
	return student

def student_to_line(student):
	return student['br_indeksa']+'|'+\
	student['ime']+'|'+\
	student['prezime']+'|'+\
	student['ime_roditelja']+'|'+\
	student['datum_rodjenja']+'|'+\
	student['JMBG']

def load(path):
	f=open(path,'r')
	lista=[]
	for red in f:
		lista.append(line_to_student(red))
	return lista

def save(path,students):
	f=open(path,'w')
	for student in students:
		print(student_to_line(student),file=f)
	f.close()

def main():
	students = load('studenti.txt')
	save('studenti1.txt',students)

if __name__ == '__main__':
	main()