import studenti_io

file_path = 'studenti.txt'
save_path = 'studenti1.txt'


def delete_student(index):
	students = studenti_io.load(file_path)
	del_index = -1
	for i in range(len(students)):
		if students[i]['br_indeksa']==index:
			del_index = i
			break
	if del_index!=-1:
		del students[del_index]
	studenti_io.save(save_path,students)

def main():
	delete_student('119')

if __name__ == '__main__':
	main()