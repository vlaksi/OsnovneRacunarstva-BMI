# imamo fajl proba1.txt
f_in = open('proba1.txt','r')
f_out = open('proba2.txt','w')
# citamo red po red iz fajla
l = f_in.readlines()
# dekodujemo poruku i snimimo je u proba2.txt
for red in l:
    s = ''
    for c in red.split('|'):
        s += chr(int(c))
    print(s, file=f_out)
f_in.close()
f_out.close()