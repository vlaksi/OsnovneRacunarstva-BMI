# korisnik unese broj meseca
broj_meseca = int(input('broj meseca: '))
# program ispise skraceni naziv meseca
meseci = ["Januar", "Februar", "Mart", "April", "Maj", "Jun", "Jul", "Avgust", "Septembar", "Oktobar", "Novembar", "Decembar"]
mesec = meseci[broj_meseca-1]
# na primer 2 -> Feb
print(mesec)