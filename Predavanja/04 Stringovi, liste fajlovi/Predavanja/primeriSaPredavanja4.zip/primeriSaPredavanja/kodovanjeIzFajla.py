# imamo zadat fajl proba.txt
f_in = open('proba.txt', 'r')
f_out = open('proba1.txt', 'w')
# sadrzaj tog fajla red po red 'kodiramo' i snimimo u fajl proba1.txt 
for red in f_in.readlines():
    s = ''
    for c in red.strip():
        s += str(ord(c))+'|'
    print(s[:-1], file=f_out)   
f_in.close()
f_out.close()