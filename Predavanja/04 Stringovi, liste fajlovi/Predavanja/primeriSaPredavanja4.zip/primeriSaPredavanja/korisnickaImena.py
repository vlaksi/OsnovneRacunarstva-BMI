# korisnik unosi ime i prezime sa tastature
ime = input('ime: ')
prezime = input('prezime: ')
# formira se korisnicko ime koje cine ime i prvih 7 karaktera prezimena
korisnicko_ime = ime+prezime[:8]
# program ispisuje korisnicko ime
print(korisnicko_ime)