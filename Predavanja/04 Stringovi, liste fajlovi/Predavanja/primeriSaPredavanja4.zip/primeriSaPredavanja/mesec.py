# korisnik unese broj meseca
broj_meseca = int(input('broj meseca: '))
# program ispise skraceni naziv meseca
meseci = "JanFebMarAprMajJunJulAvgSepOktNovDec"
mesec = meseci[(broj_meseca-1)*3:broj_meseca*3]
# na primer 2 -> Feb
print(mesec)