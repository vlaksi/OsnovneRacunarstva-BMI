# inverzno od kodovanja
# prosledimo 'kodovanu' poruku
tekst = input('unesi kodiranu poruku')
# dobijemo originalni tekst
# na primer:
# 104|101|108|108|111|32|119|111|114|108|100 => 'hello world'
dekodovana_poruka = ''
for c in tekst.split('|'):
    dekodovana_poruka += chr(int(c))

print(dekodovana_poruka)