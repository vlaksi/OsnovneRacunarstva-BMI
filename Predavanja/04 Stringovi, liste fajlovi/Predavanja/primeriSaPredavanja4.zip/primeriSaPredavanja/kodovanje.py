# korisnik unese tekst sa tastature
tekst = input('unesi tekst: ')
# sistem ispise "kodiranu" poruku:
# svako slovo iz teksta je zamenjeno njegovim rednim brojem
# na primer ABBA = 65666665
kodirana_poruka = ''
for chr in tekst:
    # kodirana_poruka = kodirana_poruka + ord(chr)
    kodirana_poruka += str(ord(chr))+'|'
kodirana_poruka = kodirana_poruka[:-1]

print(kodirana_poruka)