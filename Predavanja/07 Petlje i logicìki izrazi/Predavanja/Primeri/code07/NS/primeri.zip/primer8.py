while True:
	number = eval(input("number: "))
	print(number)
	if number>0:
		break
