number = -1
while number<0:
	number = eval(input("number: "))
	print(number)
