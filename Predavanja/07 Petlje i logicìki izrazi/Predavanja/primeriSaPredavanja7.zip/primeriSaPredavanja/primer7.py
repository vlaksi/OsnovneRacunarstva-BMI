# x = 0
# repeat:
#     x+=1
#     print(x)
# until x!=5

x = 0
while True:
    x += 1
    print(x)
    if x==5:
        break
