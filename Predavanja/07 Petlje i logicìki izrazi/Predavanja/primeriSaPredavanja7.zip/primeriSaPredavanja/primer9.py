f = open('brojevi.csv','r')
s = 0
red = f.readline()
while red!='':
    s += float(red.strip())
    red = f.readline()
f.close()
print(s)

