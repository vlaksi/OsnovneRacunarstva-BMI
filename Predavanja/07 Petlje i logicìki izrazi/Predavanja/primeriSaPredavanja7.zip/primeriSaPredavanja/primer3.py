x = 3
while x > -1:
    x -= 0.26
    print(x)