osoba = {'ime': 'Pera', 'prezime': 'Peric', 'broj licne karte': 213, 'adresa': 'Fruskogorska 21', 'adresa1': 'Strazilovska 18', 'adresa2': 'Cara Dusana 21'}
def prikazi():
    print('osoba u m1:')
    print(osoba)