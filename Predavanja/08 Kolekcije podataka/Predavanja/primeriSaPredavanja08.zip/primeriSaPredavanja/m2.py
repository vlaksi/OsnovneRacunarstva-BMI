import m1

m1.osoba['bla']='bla bla'
print('osoba u m2')
print(m1.osoba)
m1.prikazi()