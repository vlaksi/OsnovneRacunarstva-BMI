# pronaci medijan podataka iz fajla brojev1.csv

def ucitaj_podatke():
    f = open('brojevi1.csv','r')
    red = f.readline()
    ret_val = []
    while red!='':
        red = red.strip()
        l = red.split(',')
        for broj in l:
            try:
                broj = float(broj)
                ret_val.append(broj)
            except:
                pass
        red = f.readline()
    f.close()
    return ret_val

def median(l):
    l.sort()
    if len(l)%2==0:
        return  (l[int(len(l)/2)]+l[int(len(l)/2)-1])/2
    else:
        return l[int(len(l)/2)]

def main():
    brojevi = ucitaj_podatke()
    print(median(brojevi))

if __name__ == '__main__':
    main()
