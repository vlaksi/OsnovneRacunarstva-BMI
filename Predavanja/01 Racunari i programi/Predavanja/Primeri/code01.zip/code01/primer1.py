def hello(name):
	print("hello",name)
	print("how are you?")
hello("Pera")