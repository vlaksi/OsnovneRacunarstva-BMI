# program ispisuje tekst "unesi temperaturu u stepenima celzijusa:"
# program prihvata korisnicki unos
c = eval(input('unesi temperaturu u stepenima celzijusa: '))
# program racuna temperaturu u F iz unete temperature u stepenima C po formuli
#   F = (9/5)*C + 32
f = (9/5)*c + 32
# program ispusje F
print('temperatura u farenhajtima je:',f)