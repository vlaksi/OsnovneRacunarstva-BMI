# korisnik unosi glavnicu i kamatnu stopu i broj godina
glavnica = eval(input('glavnica: '))
kamata = eval(input('kamata: '))
broj_godina = eval(input('broj godina: '))
# sistem racuna ukupan iznos koji korisnik treba da vrati
#   nakon isteka perioda otplate kredita
#       koliko godina se vraca kredit, toliko puta ponavljamo:
#       glavnica = glavnica + glavnica * kamata
for i in range(broj_godina):
    glavnica = glavnica + glavnica*kamata
# sistem ispisuje iznos
print('ukupno za vracanje:',glavnica)