def check_float(x):
    try:
        float(x)
        return True
    except:
        return False

print(check_float('1.5'))
print(check_float('bla'))