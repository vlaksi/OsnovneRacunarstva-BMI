from random import random
x = 5
while random() > 0.05:
    print('!')