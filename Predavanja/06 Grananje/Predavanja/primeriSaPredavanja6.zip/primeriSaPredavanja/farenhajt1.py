def main():
    c = eval(input("What is the Celsius temperature? "))
    f = 9/5 * c + 32
    if f<30:
        print("Very cold!")
    if f>90:
        print("Very hot!")
    print("The temperature is", f, "degrees Fahrenheit.")

if __name__ == '__main__':
    main()