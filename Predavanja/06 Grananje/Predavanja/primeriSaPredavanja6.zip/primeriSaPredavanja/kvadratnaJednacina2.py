# data je jednacina oblika
# a*x**2+b*x+c=0
# funkcija prima parametre a, b i c
# funkcija vraca vrednosti x1 i x2
# x1,2 = (-b+-sqrt(b**2-4*a*c))/(2*a)

from math import sqrt

def kv_jednacina(a,b,c):
    d = b*b - 4*a*c 
    if d < 0:
        return None
    else:
        x1 = (-b + (sqrt(d)))/(2*a )
        x2 = (-b - (sqrt(d)))/(2*a )
        return x1, x2

if __name__=='__main__':
    rezultat = kv_jednacina(1,2,1)
    print(rezultat)
