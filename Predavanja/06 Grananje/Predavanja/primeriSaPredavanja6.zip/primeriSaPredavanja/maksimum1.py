# imamo tri broja: x1, x2 i x3
# napisati funkciju koja pronalazi najveci od ova tri broja
def max_1(x1, x2, x3):
    if x1>=x2 and x1>=x3:
        ret_val = x1
    elif x2>=x1 and x2>=x3:
        ret_val = x2
    else:
        ret_val = x3
    return ret_val

def max_2(x1, x2, x3, x4):
    if x1>=x2 and x1>=x3 and x1>x4:
        ret_val = x1
    elif x2>=x1 and x2>=x3 and x2>x4:
        ret_val = x2
    elif x3>=x1 and x3>=x2 and x3>x4:
        ret_val = x3
    else:
        ret_val = x4
    return ret_val

def max_3(x1, x2, x3, x4):
    ret_val = x1
    if x2 > ret_val:
        ret_val = x2
    if x3 > ret_val:
        ret_val = x3
    if x4 > ret_val:
        ret_val = x4
    return ret_val

def max_4(l):
    ret_val = l[0]
    for x in l:
        if x > ret_val:
            ret_val = x
    return ret_val


print(max_4([1,2,3,2,3,4,5,6,5,4,2,2,3,4,5]))