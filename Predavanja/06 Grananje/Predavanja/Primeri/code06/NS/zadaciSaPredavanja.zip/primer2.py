komanda = input("komanda: ")
if komanda.lower()=="kraj":
    print("dovidjenja")