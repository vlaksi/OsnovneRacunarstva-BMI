import referentiIO
import studentiIO

def prijava():
    referenti = referentiIO.ucitaj('referenti.csv')
    brojac = 0
    while True:
        korisnicko_ime = input('korisnicko ime:')
        lozinka = input('lozinka:')
        brojac += 1 
        for referent in referenti:
            if korisnicko_ime == referent['korisnicko_ime'] and lozinka == referent['lozinka']:
                return True
        if brojac >= 3:
            return False

def prikazi_meni():
    print('1) pronalazenje studenta po broju indeksa')
    print('2) pronalazenje studenta po prezimenu')
    print('3) prikaz svih studenata')

def main():
    if prijava():
        prikazi_meni()
        komanda = input('komanda:')
        if komanda == '1':
            # pronalazenje studenta po indeksu
            pass
        elif komanda == '2':
            # pronalazenje studenata po prezimenu
            pass
        elif komanda == '3':
            # TODO refaktorisati ovaj kod!!! 
            studenti = studentiIO.ucitaj('studenti.csv')
            studenti.sort(key = lambda x:x['prezime'])
            print('broj indeksa|ime     |prezime    |JMBG')
            print('--------------------------------------')
            for student in studenti:
                print(student['broj_indeksa']+'|'+student['ime']+'|'+student['prezime']+'|'+student['JMBG'])

if __name__ == "__main__":
    main()
