def red_u_recnik(red):
    red_l = red.split('|')
    student = {'broj_indeksa': red_l[0], 'ime': red_l[1], 'prezime': red_l[2],'JMBG': red_l[3]}
    return student

def ucitaj(fajl):
    f_in = open(fajl,'r')
    redovi = f_in.readlines()
    studenti = []
    for red in redovi:
        studenti.append(red_u_recnik(red.strip()))
    return studenti 
