# korisnik unosi broj ljudi koji treba da stoje u redu
n = eval(input('n: '))
# program racuna broj nacina na koji oni mogu da se poredjaju
# n! = n*(n-1)*(n-2)*...*3*2
n_f = 1
for i in range(n,0,-1):
    n_f = n_f*i
# program ispisuje izracunatu vrednost
print(n_f)