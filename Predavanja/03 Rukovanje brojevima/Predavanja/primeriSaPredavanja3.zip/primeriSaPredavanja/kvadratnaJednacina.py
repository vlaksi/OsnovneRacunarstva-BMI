# ax*x+b*x+c=0
import math
# korisnik unosi parametre a,b,c
a = eval(input('a: '))
b = eval(input('b: '))
c = eval(input('c: '))
# program racuna vrednosti x1 i x2 tako da bude zadovoljena jednacina
# x1,2 = (-b +- sqrt(b*b-4ac))/2a
x1 = (-b + math.sqrt(b*b-4*a*c))/(2*a)
x2 = (-b - math.sqrt(b*b-4*a*c))/(2*a)
# program ispisuje vrednosti
print('x1, x2:',x1,x2)