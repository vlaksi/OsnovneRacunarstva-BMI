def f(x):
    if x==1:
        return 1
    if x==2:
        return 4
    if x==3:
        return 9
    if x==4:
        return 16

def f1(x):
    return x*x

print(f1(22))