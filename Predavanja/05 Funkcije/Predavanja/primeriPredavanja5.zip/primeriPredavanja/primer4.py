w = 20

def f(x):
    y = x+3
    w = 30
    y = y-w
    return y

z = f(5)
pass
