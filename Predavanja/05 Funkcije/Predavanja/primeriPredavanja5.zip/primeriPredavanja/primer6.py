def saberi_i_oduzmi(x,y):
    return x+y, x-y

a,b = saberi_i_oduzmi(3,1)
print(a)
print(b)

# a = saberi_i_oduzmi(3,1)
# print(type(a))