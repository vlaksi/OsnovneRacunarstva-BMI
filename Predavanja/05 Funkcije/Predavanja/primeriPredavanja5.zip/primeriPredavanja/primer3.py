l = [1,2,3]

def f():
    l.pop()

f()
print(l)