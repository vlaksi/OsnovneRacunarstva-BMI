import primer7
print(primer7.obracun(12000,0.1,5))