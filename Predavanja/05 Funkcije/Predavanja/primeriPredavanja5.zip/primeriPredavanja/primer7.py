from random import random

# odredi iznos na racunu nakon zadatog broja godina, za zadatu glavnicu i zadatu godisnju kamatu
def obracun(glavnica, kamata, broj_godina):
    for i in range(broj_godina):
        glavnica += glavnica*kamata + random()*glavnica
        # glavnica = glavnica + glavnica*kamata
    return glavnica

if __name__=='__main__':
    g = 10000
    k = 0.1
    bg = 10
    print(obracun(g,k,bg))
    print(g) 

