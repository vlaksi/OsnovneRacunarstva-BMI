def f(x,y):
    print(x+y)
    # return None

def f1(x,y):
    return x+y


# a = f(2,3)
b = f1(2,3)
print(b)