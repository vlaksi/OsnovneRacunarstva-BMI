# odredi iznos na racunu nakon zadatog broja godina, za zadatu glavnicu i zadatu godisnju kamatu
def obracun(glavnica, kamata, broj_godina):
    glavnica = [glavnica[0],glavnica[1],glavnica[2]]
    for godina in range(broj_godina):
        for i in range(len(glavnica)):
            glavnica[i] += glavnica[i]*kamata
            # glavnica = glavnica + glavnica*kamata
    return glavnica

g = [10000,3000,2000]
k = 0.1
bg = 10
print(obracun(g,k,bg))
print(g) 